/* =========================================================
   SERVICE WORKER – membuat website bisa dipasang sebagai aplikasi
   dan tetap terbuka walau sinyal hilang.
   Setiap kali ada perubahan besar, naikkan angka VERSI di bawah.
   ========================================================= */
const VERSI = "aljabar-v1";
const FILE_UTAMA = [
  "./", "./index.html", "./kenalan.html", "./metode.html", "./contoh.html", "./kuis.html",
  "./css/style.css", "./js/script.js", "./manifest.json",
  "./icons/icon-192.png", "./icons/icon-512.png"
];

// Simpan file utama saat aplikasi dipasang
self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(VERSI).then((c) => c.addAll(FILE_UTAMA)));
  self.skipWaiting();
});

// Hapus simpanan versi lama
self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys().then((kunci) => Promise.all(kunci.filter((k) => k !== VERSI).map((k) => caches.delete(k))))
  );
  self.clients.claim();
});

// Ambil dari internet dulu (supaya selalu terbaru); kalau tidak ada sinyal, pakai simpanan
self.addEventListener("fetch", (e) => {
  if (e.request.method !== "GET" || new URL(e.request.url).origin !== location.origin) return;
  e.respondWith(
    fetch(e.request)
      .then((jawab) => {
        const salinan = jawab.clone();
        caches.open(VERSI).then((c) => c.put(e.request, salinan));
        return jawab;
      })
      .catch(() => caches.match(e.request).then((r) => r || caches.match("./index.html")))
  );
});
